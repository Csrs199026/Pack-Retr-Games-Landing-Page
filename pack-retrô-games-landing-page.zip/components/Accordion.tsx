import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface AccordionProps {
  question: string;
  answer: string;
}

const Accordion: React.FC<AccordionProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-white/5 last:border-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 px-8 flex justify-between items-center text-left focus:outline-none hover:bg-white/5 active:bg-white/10 transition-all"
      >
        <span className="text-white font-black text-[15px] uppercase tracking-wide leading-tight pr-6">{question}</span>
        <div className={`transition-transform duration-500 ${isOpen ? 'rotate-180' : ''}`}>
          <ChevronDown className={`w-6 h-6 ${isOpen ? 'text-indigo-400' : 'text-slate-500'}`} />
        </div>
      </button>
      {isOpen && (
        <div className="px-8 pb-6 text-slate-400 text-sm font-medium leading-relaxed animate-in fade-in slide-in-from-top-4 duration-500">
          {answer}
        </div>
      )}
    </div>
  );
};

export default Accordion;