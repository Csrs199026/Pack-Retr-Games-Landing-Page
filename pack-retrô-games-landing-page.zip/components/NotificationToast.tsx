import React, { useState, useEffect } from 'react';
import { CheckCircle } from 'lucide-react';

const NAMES = ['Leonardo', 'Ricardo', 'Mariana', 'José', 'Ana', 'Gustavo', 'Felipe', 'Bia', 'Rodrigo', 'Camila', 'Tiago'];

const NotificationToast: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [name, setName] = useState(NAMES[0]);

  useEffect(() => {
    const showRandomNotification = () => {
      setName(NAMES[Math.floor(Math.random() * NAMES.length)]);
      setVisible(true);
      setTimeout(() => setVisible(false), 4500);
    };

    const interval = setInterval(showRandomNotification, 10000);
    setTimeout(showRandomNotification, 2000);

    return () => clearInterval(interval);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-24 left-4 right-4 md:bottom-6 md:left-6 md:right-auto z-50 animate-in slide-in-from-left-full duration-700">
      <div className="bg-gradient-to-r from-emerald-500 to-green-600 text-white px-5 py-3 rounded-2xl shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-center space-x-3 border border-white/20 backdrop-blur-md">
        <div className="bg-white/20 p-1.5 rounded-full">
          <CheckCircle className="w-5 h-5 text-white" />
        </div>
        <span className="text-sm font-black uppercase tracking-tight">
          {name} acaba de baixar o <span className="text-yellow-300">Pack Premium!</span>
        </span>
      </div>
    </div>
  );
};

export default NotificationToast;